KSR Parameter Logger 1.0.16 - performance patch

Supports Kerbal Space Race legacy campaigns and Launch & Logs campaigns.
Requires the existing Harmony 2.2.1 and SpaceAge 1.3.8 supplied by the launcher.

The original KSRParameterLogger.dll is unchanged. The additional runtime patch
caches configuration using file length and last-write time, captures current
SpaceAge achievements on change, and writes complete CSVs on one background
thread. All 13 CSV columns and campaign-relative date rules are preserved.
Explicit record synchronization still refreshes and flushes exports first.

SpaceAge records are read from the current in-memory achievement list instead
of the previously loaded save copy. Export snapshot timestamps advance when
data changes or an explicit synchronization requests a fresh export.
Contract events, science/payload records, crew mission-time exports and server
API/authentication/campaign-selection behavior remain as in the original logger.

Install: merge GameData into the KSP directory, or update using KSR Launcher.
Do not delete PluginData. Restart KSP to load the patch.
Rollback: remove GameData/KSRParameterLogger/Plugins/KerbalSpaceRace.LoggerPerformance.dll
and restart KSP. The original logger DLL is retained.

Verification: 25 offline checks with the real Harmony library; live flight test
with UniqueOrbits/Kerbin 45 -> 46 and HeaviestVesselInOrbit/Kerbin updated to the
new vessel. No patch errors observed. In-game stutter reduction was reported.
